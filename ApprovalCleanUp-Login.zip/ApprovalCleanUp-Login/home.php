<?php
include "config.php";

// Check user login or not
if (!isset($_SESSION['employee_id'])) {
	header('Location: index.php');
}
?>
<!doctype html>
<html>

<head>
	<meta charset="utf-8">
	<title>Home Page</title>
	<link href="style1.css?v=1" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
</head>
<!-- <body> -->

<body class="loggedin">
	<nav class="navtop">
		<div>
			<h1>Route Approval Clean Up</h1>
			<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
		</div>
	</nav>
	<div class="content">
		<h2>Home Page</h2>
		<p>Welcome <?=$_SESSION['employee_name']?>,
		<p>Job Title: <?= $_SESSION['job_title'] ?></p>
	</div>
</body>

</html>