-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 21, 2021 at 03:27 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ApprovalCleanup`
--

-- --------------------------------------------------------

--
-- Table structure for table `approval_routing`
--

CREATE TABLE `approval_routing` (
  `LU_NAME` varchar(50) NOT NULL,
  `KEY_REF` varchar(250) NOT NULL,
  `STEP_NO` varchar(50) NOT NULL,
  `DESCRIPTION` varchar(50) NOT NULL,
  `APP_DATE` datetime(6) DEFAULT NULL,
  `NOTE` varchar(250) DEFAULT NULL,
  `PREV_APPROVAL_DATE` datetime(6) DEFAULT NULL,
  `PERSON_ID` varchar(50) NOT NULL,
  `APPROVAL_STATUS` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `company_emp`
--

CREATE TABLE `company_emp` (
  `COMPANY` varchar(50) NOT NULL,
  `PERSON_ID` varchar(50) NOT NULL,
  `EMPLOYEE_ID` varchar(50) NOT NULL,
  `EXPIRE_DATE` varchar(50) DEFAULT NULL,
  `ROWKEY` varchar(50) NOT NULL,
  `FNAME` varchar(50) NOT NULL,
  `LNAME` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `company_emp`
--

INSERT INTO `company_emp` (`COMPANY`, `PERSON_ID`, `EMPLOYEE_ID`, `EXPIRE_DATE`, `ROWKEY`, `FNAME`, `LNAME`) VALUES
('US0100', '100001', '3280', NULL, 'AAATS+AAHAAACwsAB3', 'Madeleine', 'Kelly'),
('US0100', '100011', '4288', NULL, 'AAATS+AAHAAACwtADB', 'Amanda', 'Russell'),
('US0100', '100013', '2681', NULL, 'AAATS+AABAAMt9wABH', 'Karen', 'Taylor'),
('US0100', '100015', '2776', NULL, 'AAATS+AAHAAACwsAAc', 'Ryan', 'Vance'),
('US0100', '100307', '8731', NULL, 'AAATS+AAHAAACwvABA', 'Joan', 'Miller');

-- --------------------------------------------------------

--
-- Table structure for table `document_group_members`
--

CREATE TABLE `document_group_members` (
  `GROUP_ID` varchar(50) NOT NULL,
  `PERSON_ID` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `emp_job_assign`
--

CREATE TABLE `emp_job_assign` (
  `COMPANY_ID` varchar(50) NOT NULL,
  `EMP_NO` varchar(50) NOT NULL,
  `VALID_FROM` datetime(6) NOT NULL,
  `JOB_ID` varchar(50) NOT NULL,
  `JOB_TITLE` varchar(50) NOT NULL,
  `VALID_TO` datetime(6) NOT NULL,
  `EMPLOYEE_STATUS` varchar(50) NOT NULL,
  `EMPLOYEE_STATUS_SEQ_NO` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `emp_job_assign`
--

INSERT INTO `emp_job_assign` (`COMPANY_ID`, `EMP_NO`, `VALID_FROM`, `JOB_ID`, `JOB_TITLE`, `VALID_TO`, `EMPLOYEE_STATUS`, `EMPLOYEE_STATUS_SEQ_NO`) VALUES
('US0100', '1029', '2012-05-31 00:00:00.000000', 'ENG25', 'Supervisor, Engineering Support', '1999-12-31 00:00:00.000000', 'Active', '1'),
('US0100', '2681', '2013-01-27 00:00:00.000000', 'ENG03', 'Engineer I, Design', '2013-02-25 00:00:00.000000', 'Active', '1'),
('US0100', '2776', '2008-01-01 00:00:00.000000', 'ITD021', 'IT', '1999-12-31 00:00:00.000000', 'Terminated', '0'),
('US0100', '3280', '2013-02-26 00:00:00.000000', 'ITD024', 'IT', '2021-05-27 00:00:00.000000', 'Active', '1'),
('US0100', '4288', '2013-02-24 00:00:00.000000', 'SALES07', 'Customer Service Representative II', '1999-12-31 00:00:00.000000', 'Active', '1'),
('US0100', '8731', '2013-02-24 00:00:00.000000', 'MAGR8', 'Manager', '1999-12-31 00:00:00.000000', 'Active', '1');

-- --------------------------------------------------------

--
-- Table structure for table `inventory_part`
--

CREATE TABLE `inventory_part` (
  `PART_NO` varchar(50) NOT NULL,
  `PART_STATUS` varchar(50) NOT NULL,
  `DESCRIPTION` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company_emp`
--
ALTER TABLE `company_emp`
  ADD PRIMARY KEY (`PERSON_ID`);

--
-- Indexes for table `emp_job_assign`
--
ALTER TABLE `emp_job_assign`
  ADD PRIMARY KEY (`EMP_NO`);

--
-- Indexes for table `inventory_part`
--
ALTER TABLE `inventory_part`
  ADD PRIMARY KEY (`PART_NO`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
