<footer id="sticky-footer">
    <div class="container text-center">
        <small>&copy; Copyright 2021 | Metrostate University - Team 3</small>
    </div>
</footer>